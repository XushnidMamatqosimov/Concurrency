package javaConcurrency.Task1;

public class Main {
    public static void main(String[] args) {
        Counter counter = new Counter();
        counter.counter();
    }
}
