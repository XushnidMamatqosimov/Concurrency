package VaqtlarBilanIshlash.Task2;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

public class Main {
    public static void main(String[] args) throws ParseException {
        SimpleDateFormat instance = new SimpleDateFormat("dd/MM/yyyy");

        String date1 = "12/12/2012";

        Date parse = instance.parse(date1);
        System.out.println(parse);




    }

}
