package regex.Task1;

public class Main {
    public static void main(String[] args) {
        System.out.println(Service.getInteger("salom mening ismim Xushnid men 19 yoshdaman va 20 tolaman;"));
        System.out.println(Service.getNumberCount("hello guys we have a presentation on 2th of the December and are you ready for that" +
                "if you are not please contact me today till 12:35 "));
        Service.digitCounter("In this fall semester we accepted over 950 students and 45 of them are Uzbeks");
        Service.bestOne("In doing so last 4 years we noticed about 25% of increase in our GDP");
    }
}
