package javaSynchronization.Task4;

public class RaceCondition {
    private int balance;

    public void withdraw (int amount){
        balance-=amount;
        System.out.println(Thread.currentThread().getName()+ " amount "+ amount+ " received: ");
    }
    public int getBalance (){
        return balance;
    }
}
