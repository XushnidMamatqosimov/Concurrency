package javaSynchronization.Task4;

public class Main {
    public static void main(String[] args) {
        RaceCondition account = new RaceCondition();

        var th1 = new Thread("Thread One");
        var th2 = new Thread("Thread Two");
        th1.start();
        th2.start();
    }
}
